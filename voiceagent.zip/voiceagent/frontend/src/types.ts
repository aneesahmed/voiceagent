export type CallStatus =
  | "idle"
  | "connecting"
  | "listening"
  | "processing"
  | "speaking"
  | "error"
  | "ended";

export interface CallAdapterCallbacks {
  onStatusChange: (status: CallStatus) => void;
  onError: (message: string) => void;
}
