import type { CallAdapterCallbacks, CallStatus } from "./types";

// Common audio contract across every transport (see CLAUDE.md decision #6).
const TARGET_SAMPLE_RATE = 8000;

// RMS above this (float samples in [-1, 1]) counts as speech, not silence.
const SILENCE_RMS_THRESHOLD = 0.02;
// How long RMS must stay below threshold, after speech was heard, before
// we consider the caller's turn over and send end_of_turn.
const SILENCE_DURATION_MS = 1000;

function downsampleTo8kHz(input: Float32Array, inputSampleRate: number): Float32Array {
  if (inputSampleRate === TARGET_SAMPLE_RATE) return input;

  const ratio = inputSampleRate / TARGET_SAMPLE_RATE;
  const outputLength = Math.floor(input.length / ratio);
  const output = new Float32Array(outputLength);

  for (let i = 0; i < outputLength; i++) {
    const srcIndex = i * ratio;
    const idxLow = Math.floor(srcIndex);
    const idxHigh = Math.min(idxLow + 1, input.length - 1);
    const frac = srcIndex - idxLow;
    output[i] = input[idxLow] * (1 - frac) + input[idxHigh] * frac;
  }

  return output;
}

function floatTo16BitPCM(input: Float32Array): Int16Array {
  const output = new Int16Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i]));
    output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return output;
}

function computeRMS(input: Float32Array): number {
  let sum = 0;
  for (let i = 0; i < input.length; i++) sum += input[i] * input[i];
  return Math.sqrt(sum / input.length);
}

// Drives one call over the /audio websocket protocol (see backend/app/main.py):
// stream raw PCM16 while the user speaks, send {"event":"end_of_turn"} on
// silence, then play back the PCM16 frames the server streams until
// {"event":"reply_end"} before listening again.
export class CallAdapter {
  private callbacks: CallAdapterCallbacks;
  private status: CallStatus = "idle";

  private ws: WebSocket | null = null;
  private audioContext: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processor: ScriptProcessorNode | null = null;

  private isCapturing = false;
  private hasSpoken = false;
  private silenceStartedAt: number | null = null;
  private playbackChunks: Int16Array[] = [];

  constructor(callbacks: CallAdapterCallbacks) {
    this.callbacks = callbacks;
  }

  async startCall(wsUrl: string): Promise<void> {
    this.setStatus("connecting");

    try {
      this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch {
      this.callbacks.onError("Microphone access denied.");
      this.setStatus("error");
      return;
    }

    this.audioContext = new AudioContext();
    this.sourceNode = this.audioContext.createMediaStreamSource(this.micStream);
    // ScriptProcessorNode is deprecated but needs no separate worklet module
    // file/build step -- simplest option for a V1 pseudo-call. Its output is
    // left untouched (silent), so connecting it to destination just makes
    // onaudioprocess fire; it doesn't loop mic audio back to the speakers.
    this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);
    this.processor.onaudioprocess = this.handleAudioProcess;
    this.sourceNode.connect(this.processor);
    this.processor.connect(this.audioContext.destination);

    this.ws = new WebSocket(wsUrl);
    this.ws.binaryType = "arraybuffer";

    this.ws.onopen = () => {
      this.isCapturing = true;
      this.setStatus("listening");
    };

    this.ws.onmessage = this.handleServerMessage;

    this.ws.onerror = () => {
      this.callbacks.onError("Connection error.");
      this.setStatus("error");
    };

    this.ws.onclose = () => {
      if (this.status !== "ended") {
        this.setStatus("ended");
      }
    };
  }

  endCall(): void {
    this.isCapturing = false;
    this.setStatus("ended");

    this.ws?.close();
    this.ws = null;

    this.processor?.disconnect();
    this.sourceNode?.disconnect();
    this.processor = null;
    this.sourceNode = null;

    this.micStream?.getTracks().forEach((track) => track.stop());
    this.micStream = null;

    this.audioContext?.close();
    this.audioContext = null;

    this.playbackChunks = [];
    this.hasSpoken = false;
    this.silenceStartedAt = null;
  }

  private setStatus(status: CallStatus) {
    this.status = status;
    this.callbacks.onStatusChange(status);
  }

  private handleAudioProcess = (event: AudioProcessingEvent) => {
    if (!this.isCapturing || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    const inputData = event.inputBuffer.getChannelData(0);
    const downsampled = downsampleTo8kHz(inputData, this.audioContext!.sampleRate);
    this.ws.send(floatTo16BitPCM(downsampled).buffer);

    const rms = computeRMS(inputData);
    const now = performance.now();

    if (rms > SILENCE_RMS_THRESHOLD) {
      this.hasSpoken = true;
      this.silenceStartedAt = null;
    } else if (this.hasSpoken) {
      if (this.silenceStartedAt === null) {
        this.silenceStartedAt = now;
      } else if (now - this.silenceStartedAt >= SILENCE_DURATION_MS) {
        this.finishTurn();
      }
    }
  };

  private finishTurn() {
    this.isCapturing = false;
    this.hasSpoken = false;
    this.silenceStartedAt = null;
    this.setStatus("processing");
    this.ws?.send(JSON.stringify({ event: "end_of_turn" }));
  }

  private handleServerMessage = (event: MessageEvent) => {
    if (typeof event.data === "string") {
      const parsed = JSON.parse(event.data);
      if (parsed.event === "reply_end") {
        this.playbackReply();
      }
      return;
    }

    this.playbackChunks.push(new Int16Array(event.data as ArrayBuffer));
  };

  private playbackReply() {
    this.setStatus("speaking");

    const totalLength = this.playbackChunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const merged = new Int16Array(totalLength);
    let offset = 0;
    for (const chunk of this.playbackChunks) {
      merged.set(chunk, offset);
      offset += chunk.length;
    }
    this.playbackChunks = [];

    if (merged.length === 0) {
      this.resumeListening();
      return;
    }

    const audioContext = this.audioContext!;
    const audioBuffer = audioContext.createBuffer(1, merged.length, TARGET_SAMPLE_RATE);
    const channelData = audioBuffer.getChannelData(0);
    for (let i = 0; i < merged.length; i++) {
      channelData[i] = merged[i] / 0x8000;
    }

    const source = audioContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContext.destination);
    source.onended = () => this.resumeListening();
    source.start();
  }

  private resumeListening() {
    if (this.status === "ended") return;
    this.isCapturing = true;
    this.setStatus("listening");
  }
}
