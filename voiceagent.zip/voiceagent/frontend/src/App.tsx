import { useCallback, useRef, useState } from "react";
import { CallAdapter } from "./CallAdapter";
import type { CallStatus } from "./types";

const WS_URL = "ws://localhost:8001/audio";

const STATUS_LABEL: Record<CallStatus, string> = {
  idle: "Ready to call",
  connecting: "Connecting...",
  listening: "Listening...",
  processing: "Thinking...",
  speaking: "Speaking...",
  error: "Something went wrong",
  ended: "Call ended",
};

export default function App() {
  const [status, setStatus] = useState<CallStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const adapterRef = useRef<CallAdapter | null>(null);

  const startCall = useCallback(async () => {
    setError(null);
    const adapter = new CallAdapter({
      onStatusChange: setStatus,
      onError: setError,
    });
    adapterRef.current = adapter;
    await adapter.startCall(WS_URL);
  }, []);

  const endCall = useCallback(() => {
    adapterRef.current?.endCall();
    adapterRef.current = null;
  }, []);

  const inCall = status !== "idle" && status !== "ended" && status !== "error";

  return (
    <main style={{ fontFamily: "sans-serif", maxWidth: 480, margin: "80px auto", textAlign: "center" }}>
      <h1>Meridian ERP Voice Assistant</h1>
      <p>{STATUS_LABEL[status]}</p>
      {error && <p style={{ color: "crimson" }}>{error}</p>}
      {inCall ? (
        <button onClick={endCall}>End Call</button>
      ) : (
        <button onClick={startCall}>Start Call</button>
      )}
    </main>
  );
}
