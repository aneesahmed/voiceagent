"""app/config.py -- centralized settings, loaded once from .env.

Every other module imports `settings` from here rather than reading
os.environ directly, so there's exactly one place that knows about env
var names and defaults.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent  # backend/
KB_DIR = BASE_DIR / "kb"


class Settings:
    # -- Gemini API --
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")

    CHAT_MODEL: str = os.getenv("CHAT_MODEL", "gemini-2.5-flash")
    STT_MODEL: str = os.getenv("STT_MODEL", "gemini-2.5-flash")
    TTS_MODEL: str = os.getenv("TTS_MODEL", "gemini-2.5-flash-preview-tts")
    TTS_VOICE: str = os.getenv("TTS_VOICE", "Aoede")

    # -- Knowledge base --
    KB_DIR: Path = KB_DIR

    # -- Server --
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8000"))

    # -- Audio --
    AUDIO_SAMPLE_RATE: int = 8000  # every transport in this project uses 8kHz/16-bit/mono PCM


settings = Settings()

if not settings.GEMINI_API_KEY:
    raise RuntimeError(
        "GEMINI_API_KEY is not set. Copy .env.example to .env and add your key."
    )