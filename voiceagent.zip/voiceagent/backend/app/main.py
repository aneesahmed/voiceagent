"""app/main.py -- FastAPI app: HTTP endpoints for text-only testing, plus
the /audio websocket for real-time voice.

Endpoints:
    GET  /health   -- liveness check
    POST /chat     -- text-only chat, for testing chat_engine.py without
                      needing audio or a browser at all
    WS   /audio    -- real-time voice: client streams raw PCM16 frames,
                      sends {"event": "end_of_turn"} when done speaking,
                      server replies with PCM16 frames followed by
                      {"event": "reply_end"}
"""
import json
import logging

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from app.chat_engine import ChatEngine
from app.stt import transcribe
from app.tts import synthesize

logger = logging.getLogger(__name__)

app = FastAPI(title="Meridian ERP Voice Assistant")

# Frontend runs on a different port during dev (Vite default 5173) -- allow it.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to the real frontend origin before production
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health():
    return {"status": "ok"}


# --- text-only chat endpoint, for testing the engine without audio ---

class ChatRequest(BaseModel):
    message: str


class ChatResponse(BaseModel):
    reply: str


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    """Fresh ChatEngine per request -- no multi-turn memory over plain
    HTTP yet. Good enough for testing single-turn KB grounding before the
    UI exists; /audio below keeps real per-call session memory."""
    engine = ChatEngine()
    reply = engine.generate_reply(req.message)
    return ChatResponse(reply=reply)


# --- real-time voice websocket ---

@app.websocket("/audio")
async def audio_ws(ws: WebSocket):
    await ws.accept()
    engine = ChatEngine()
    audio_buffer = bytearray()

    logger.info("call connected")

    try:
        while True:
            message = await ws.receive()

            if message.get("bytes") is not None:
                audio_buffer += message["bytes"]
                continue

            if message.get("text") is not None:
                try:
                    event = json.loads(message["text"])
                except json.JSONDecodeError:
                    continue

                if event.get("event") == "end_of_turn":
                    if not audio_buffer:
                        continue

                    heard = transcribe(bytes(audio_buffer))
                    audio_buffer.clear()
                    logger.info(f"caller said: {heard!r}")

                    if not heard:
                        continue

                    reply_text = engine.generate_reply(heard)
                    logger.info(f"agent reply: {reply_text!r}")

                    reply_audio = synthesize(reply_text)

                    frame_size = 640  # 320 samples * 2 bytes = 40ms @ 8kHz
                    for i in range(0, len(reply_audio), frame_size):
                        await ws.send_bytes(reply_audio[i : i + frame_size])

                    await ws.send_text(json.dumps({"event": "reply_end"}))

    except WebSocketDisconnect:
        logger.info("call disconnected")